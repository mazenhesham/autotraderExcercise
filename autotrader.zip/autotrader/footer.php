        </div><!-- .site-content -->
        
        <footer id="colophon" class="site-footer" role="contentinfo">
            <div class="site-info container">
           All rights reserved. Developed by <a href = "https://mazenhesham.com" target = "_blank">Mazen Hesham</a>
        </footer>
     

    </div><!-- site-inner -->
</div><!-- site -->

<?php wp_footer(); ?>
</body>
</html>